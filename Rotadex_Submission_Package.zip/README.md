# Project Submission & Deployment Links


## 1. Live Deployment & Host Information

* **Live Interactive 3D CAD Assembly Viewer:**
  [https://rotadex-one-hand.onrender.com](https://rotadex-one-hand.onrender.com)
  
  The website has been deployed as a high-fidelity standalone WebGL CAD application. You can view, rotate, pan, and zoom the model. You can also click **Dispense Pill** to watch the indexing pawl rotate the carousel, or **Explode** to view the internal ratchet system.

## 2. GitHub Repository
* **Repository URL:** [https://github.com/shailyM123/rotadex-one-hand](https://github.com/shailyM123/rotadex-one-hand)
* Contains all source code, WebGL rendering files, OpenSCAD CAD assembly file, and STL components.

## 3. Package Directory Mapping
This zip folder is organized into the following required submission items:
* 📁 **06_Final_CAD_Assembly/** - Contains the OpenSCAD design script and all 11 component STL files.
* 📄 **01_Design_Opportunity_and_Problem_Definition.html / .md** - Problem statement and requirements analysis.
* 📄 **02_User_Persona_and_Scenario.html / .md** - Dada Ji user persona and observational daily scenario.
* 📄 **03_User_Research_Summary.html / .md** - Primary patient observation summary and ergonomic insights.
* 📄 **04_Concept_Sketches_and_Descriptions.html / .md** - Descriptions of 3 alternatives + concept image sketch.
* 📄 **05_Morphological_Chart_and_Decision_Matrix.html / .md** - Systematic concept selection chart and matrix table.
* 🖼️ **04_Concept_Sketches.jpg** - Pencil sketch drawing of concepts.
* 🖼️ **05_Decision_Matrix.png** - Matrix analysis plot image.
* 🖼️ **05_Morphological_Chart.png** - Morphological chart plot image.
