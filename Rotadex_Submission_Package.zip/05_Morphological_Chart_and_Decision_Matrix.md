# Morphological Chart & Decision Matrix


## 1. Morphological Analysis
The Morphological Chart helps explore the design space by isolating sub-functions and identifying alternative mechanisms. The highlighted paths indicate the engineering choices compiled for the final Rotadex assembly. Refer to [05_Morphological_Chart.png](05_Morphological_Chart.png).

## 2. Concept Selection via Decision Matrix
To evaluate the concepts objectively, a weighted decision matrix was compiled against our functional requirements. Each criteria is weighted by import, and scores (1 to 10) are applied to rank the concepts. Concept 1 (Rotadex) scored the highest overall (8.35/10), making it the selected engineering concept. Refer to [05_Decision_Matrix.png](05_Decision_Matrix.png).

## 3. Engineering Rationale for Selection
* **Palm-Press Input:** Translates 100% of downward vertical force into rotation. Unlike Concept 2 (horizontal lever), it pushes the device directly into the tabletop, utilizing gravity to increase grip and prevent sliding.
* **Gravity Dispense:** The carousel compartment aligns over a single gravity drop channel, eliminating manual sliding links that can wear out.
* **Ramped Scoop:** By dropping pills into a wide scoop rather than keeping them in compartments, we replace pinching with a sweep gesture.
