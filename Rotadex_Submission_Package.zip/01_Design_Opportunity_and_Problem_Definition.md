# Design Opportunity & Problem Definition


## 1. Background & Context
In India and globally, millions of geriatric individuals and hemiplegic stroke survivors face severe motor coordination impairments. Standard medical regimes require patients to take multiple pills daily, typically organized in containers with child-proof safety caps, snap-off tabs, or small slide dividers. While child-proofing protects minors, it introduces massive usability barriers for individuals with limited dexterity, osteoarthritis, or single-arm paralysis.

## 2. Problem Statement
Standard pharmaceutical packaging and weekly pill organizers require **fine motor pinching, dual-hand grip coordination, and torsional twisting forces**. Elderly patients with severe joint deformation or stroke survivors with hemiplegia cannot open these containers independently. This results in regular pill spills, high psychological frustration, and severe medication non-adherence (missing critical daily doses), causing poor health outcomes.

## 3. User-Centered Design Opportunity
There is a major opportunity to design an affordable, purely mechanical, non-invasive medication dispenser that can be stabilized on a tabletop and operated **entirely with one hand using a single gross motor palm press**. The device must automatically segment pills by day, index forward to prevent double-dosing, and dispense pills into an ergonomic scoop cup that allows pill retrieval without pinching.

## 4. Functional Engineering Requirements
* **Single-Hand Operation:** No simultaneous holding/twisting required; all interactions must be doable with a single hand.
* **Mechanical Stability:** The device must not slide, tip, or tilt when subjected to vertical force of up to 40 Newtons.
* **Anti-Double Dose Security:** An indexing mechanism must advance exactly one compartment per press and lock against reverse rotation.
* **Ergonomic Retrieval:** A ramped scoop cup must assist in retrieving round and oblong pills without finger-pinching.
