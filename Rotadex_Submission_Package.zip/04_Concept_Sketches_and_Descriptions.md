# Concept Generation & Design Selection


## 1. Concept Descriptions
During the design brainstorming phase, three alternative concepts were generated and analyzed:

### Concept 1: Rotadex Rotary Indexing Cylinder (Selected Design)
A vertically stacked device featuring a 7-day pill carousel. An indexing pawl arm, connected to a vertical plunger shaft, rotates a ratchet wheel by exactly 51.4 degrees on each palm press. Pills are gravity-fed into a wide scoop drawer. This design maximizes stability, relies on a simple gross-motor palm press, and uses mechanical locking to prevent reverse rotation.

### Concept 2: Linear Slider-Tray
A horizontal rectangular box with a sliding top tray. Pressing a side lever moves the tray forward, releasing a pill drawer using a spring mechanism. While simple, it requires high horizontal shearing force (which causes the box to slide along the table unless held by the other hand) and contains multiple narrow channels prone to pill jamming.

### Concept 3: Flip-Lid Rotary Wheel
A circular flat dial where each daily segment is sealed by a spring-loaded lid. Small plastic tabs are pressed by the user to release the latch for the corresponding day. Observational analysis showed that pressing small tabs requires high finger dexterity and pinch force, making it inaccessible for patients with severe arthritis.

## 2. Pencil Concept Sketches
Refer to the attached image file [04_Concept_Sketches.jpg](04_Concept_Sketches.jpg) in this folder.
