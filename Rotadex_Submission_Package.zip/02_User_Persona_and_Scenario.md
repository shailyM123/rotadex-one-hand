# User Persona & Use Scenario


## 1. User Persona

### Ramesh Prasad (Dada Ji)
* **Age:** 72
* **Location:** Jaipur, Rajasthan
* **Profession:** Retired Postmaster
* **Clinical Condition:** Hemiplegia (paralysis of the left arm and leg due to a stroke last year) and severe osteoarthritis in his dominant right hand.
* **Needs & Motivations:** Ramesh takes four daily medications (cardiac, blood pressure, blood thinners, and joint pain). He lives with his son and daughter-in-law but feels intensely guilty and frustrated having to ask them to open his medicine bottles or fill his pill boxes every single morning. He highly values personal autonomy.
* **Frustrations:** Frequently drops tiny pills when trying to pinch them out of small plastic compartments; struggles to unscrew twist caps; feels like a burden to his family.

## 2. User Scenario

* **Context:** Morning medication routine in Jaipur. Ramesh sits alone at the dining table with his glass of water.

1. Ramesh approaches the dining table where the **Rotadex** dispenser sits. The device is stable on the flat wooden table, held securely by heavy non-slip silicone feet.
2. Ramesh places his right palm on the large, blue dome button at the top of the Rotadex. He does not need to use his paralyzed left hand.
3. Using a single downward gross motor press (using his arm and body weight), he presses the dome. The internal plunger compresses the spring and indexes the carousel wheel.
4. A clear mechanical *click* confirms the pawl has rotated the ratchet wheel. The day label advances from **MON** to **TUE**.
5. Ramesh's Tuesday dose of pills falls through the gravity chute and lands in the curved dispenser scoop.
6. Ramesh slides his hand flat along the table surface, sweeps his fingers through the wide scoop cup in a natural cupping motion, easily retrieves the pills without pinching, and drinks his water. He has successfully taken his morning medication with zero assistance.
