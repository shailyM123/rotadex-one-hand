# Interactive 3D CAD Assembly Viewer Link


### Live 3D CAD Model Viewer Link:
👉 **[https://rotadex-one-hand.onrender.com](https://rotadex-one-hand.onrender.com)**

Click the link above to open the live interactive 3D model viewer in your web browser. You can rotate, zoom, pan, and trigger animations (Dispense Pill, Explode assembly, Wireframe mesh).

### Viewer Features:
* **3D Rotate:** Hold left mouse click and drag to orbit around the assembly.
* **3D Zoom & Pan:** Use scroll wheel to zoom. Hold right-click and drag to pan the camera view.
* **Interactive Dispense:** Click the *Dispense Pill* button to watch the vertical plunger push the ratchet mechanism, rotating the carousel and dropping a pill into the scoop cup.
* **Exploded View:** Click *Explode* to separate the 11 component parts and view the internal indexing ratchet and spring assembly.
